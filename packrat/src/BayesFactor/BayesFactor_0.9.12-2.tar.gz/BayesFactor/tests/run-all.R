library(testthat)
library(BayesFactor)

test_package("BayesFactor")